import React, { useEffect, useState } from 'react'
import axios from 'axios'
import './All.css'

export default function All() {
    const [response,setresponse] = useState([])
    useEffect(() => {
        const fetchitems = async () =>{
            const result = await axios.get("http://localhost:5000/all");
            setresponse(result.data);
        }
        fetchitems();
        
    },[]);
  return (
    <div className="container">
        
        <h1 id='h21'>GuitarTube</h1>
        <div className="content-list">
        {
            response.map((item) => {
                return(
                    <div key={item.id} className="content-item">
                        <iframe src={`https://www.youtube.com/embed/${item.link}`}></iframe>
                        <p>{item.name}</p>
                    </div>
                )
            })
        }
        </div>
        <footer>This is footer section</footer>
    </div>
  )
}
