import logo from './logo.svg';
import './App.css';

import Home from './Home';
import All from './All';
import Search from './Search';
import {BrowserRouter as Router,Routes,Route,Link} from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <Router>
      <ul>
        <li><Link to='/'>Home</Link></li>
        <li><Link to='/all'>All</Link></li>
        <li><Link to='/search'>Search</Link></li>
        
      </ul>
        
        <Routes>
          <Route path='/' element = {<Home/>}/>
          <Route path='/all' element = {<All/>}/>
          <Route path='/search' element = {<Search/>}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
