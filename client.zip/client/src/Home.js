import React from 'react'
import './Home.css'

export default function Home() {
  return (
    <div>
    <img id ='img1' src='https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Z3VpdGFyaXN0fGVufDB8fDB8fHww&w=1000&q=80'></img>
    <h1 id='h11'>Welcome to GuitarTube !!</h1>
    <h1 id='h12'>A guitarist's YouTube </h1>
    </div>
  )
}
