import axios from 'axios';
import React, { useState } from 'react'
import './Search.css'


export default function Search() {

    const[response,setresponse] = useState([])
    const[val,setval] = useState('')

    const handlesubmit = async (e) =>{
        e.preventDefault();

        try
        {
            const ans = await axios.post('http://localhost:5000/search',{val:val});
            setresponse(ans.data)
        }
        catch(err)
        {
            console.log(err.message);
        }
    }
  return (
    <div className="container">
        
        <h1 id='h31'>Search Video Tutorial</h1>
        <form className="search-container">
            <input type='text' placeholder='Search...' onChange={(event)=>{setval(event.target.value)}} className="search-input"/>
            <input type='submit' className="search-button" onClick={handlesubmit}/>
        </form>
        <div className="content-list">
        {
            response.map((item) =>{
                return(
                    <div key={item.id} className="content-item">
                        <iframe src={`https://www.youtube.com/embed/${item.link}`}></iframe>
                        <p>{item.name}</p>
                    </div>
                )
            })
        }
        </div>
    </div>
  )
}
